
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ana Clara
 */
public class PlanosModel {

    static void create(PlanosBean m, Connection con) throws SQLException {
        PreparedStatement st;
            st = con.prepareStatement("INSERT INTO planos (nome_plano, descricao_plano, duracao_plano, tipo_acomodacao, preco_plano, restricao_especie, disponibilidade) "
                    + "VALUES (?,?,?,?,?,?,?)");
            st.setString(1, m.getNome_plano());
            st.setString(2, m.getDescricao_plano());
            st.setInt(3, m.Duracao_plano());       
            st.setString(4, m.getTipo_acomodacao());
            st.setDecimal(5, m.getPreco_plano());       //revisar tipo variavel
            st.setString(6, m.getRestricao_especie());
			st.setBoolean(7, m.getDisponibilidade()); //revisar tipo variavel
            
            st.execute();
            st.close();
    }
    
    static HashSet listAll(Connection con) throws SQLException {
        Statement st;
        HashSet list = new HashSet();
            st = con.createStatement();
            String sql = "SELECT nome_plano, descricao_plano, duracao_plano, tipo_acomodacao, preco_plano, restricao_especie, disponibilidade FROM planos";
            ResultSet result = st.executeQuery(sql);
            while(result.next()) {
                list.add(new PlanosBean(result.getString(1), result.getString(2), result.getInt(3), 
                result.getString(4), result.getDecimal(5), result.getString(6), result.getBoolean(7)));
            }
        return list;
    }    

    static HashSet listAllWithClientes(Connection con) throws SQLException {
        Statement st;
        HashSet list = new HashSet();
        st = con.createStatement();
        String sql = "SELECT nome_plano, descricao_plano, duracao_plano, tipo_acomodacao, preco_plano, restricao_especie, disponibilidade FROM planos NATURAL JOIN clientes";
        ResultSet result = st.executeQuery(sql);
        while(result.next()) {
            AnimaisBean mb = new PlanosBean(result.getString(1), result.getString(2), result.getInt(3), 
                result.getString(4), result.getDecimal(5), result.getString(6), result.getBoolean(7);
            //AmbulatoriosBean a = new AmbulatoriosBean(result.getInt(7), result.getInt(8), result.getInt(9));
            //mb.setAmbulatorio(a);
            list.add(mb);
        }
        return list;
    }

    /*static HashSet listAllWithClientes(Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }*/
}
