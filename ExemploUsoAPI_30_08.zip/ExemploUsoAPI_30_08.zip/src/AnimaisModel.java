
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ana Clara
 */
public class AnimaisModel {

    static void create(AnimaisBean m, Connection con) throws SQLException {
        PreparedStatement st;
            st = con.prepareStatement("INSERT INTO animais (nome_animal, especie_animal, raca, idade, sexo_animal, observacao) "
                    + "VALUES (?,?,?,?,?,?)");
            st.setString(1, m.getNome_animal());
            st.setString(2, m.getEspecie_animal());
            st.setString(3, m.getRaca());       
            st.setInt(4, m.getIdade());
            st.setString(5, m.getSexo_animal());
            st.setString(6, m.getObservacao());
            
            st.execute();
            st.close();
    }
    
    static HashSet listAll(Connection con) throws SQLException {
        Statement st;
        HashSet list = new HashSet();
            st = con.createStatement();
            String sql = "SELECT nome_animal, especie_animal, raca, idade, sexo_animal, observacao FROM animais";
            ResultSet result = st.executeQuery(sql);
            while(result.next()) {
                list.add(new AnimaisBean(result.getString(1), result.getString(2), result.getString(3), 
                result.getInt(4), result.getString(5), result.getString(6)));
            }
        return list;
    }    

    static HashSet listAllWithClientes(Connection con) throws SQLException {
        Statement st;
        HashSet list = new HashSet();
        st = con.createStatement();
        String sql = "SELECT nome_animal, especie_animal, raca, idade, sexo_animal, observacao FROM animais NATURAL JOIN clientes";
        ResultSet result = st.executeQuery(sql);
        while(result.next()) {
            AnimaisBean mb = new AnimaisBean(result.getString(1), result.getString(2), result.getString(3), 
                result.getInt(4),result.getString(5),result.getString(6));
            //AmbulatoriosBean a = new AmbulatoriosBean(result.getInt(7), result.getInt(8), result.getInt(9));
            //mb.setAmbulatorio(a);
            list.add(mb);
        }
        return list;
    }

    /*static HashSet listAllWithClientes(Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }*/
}
