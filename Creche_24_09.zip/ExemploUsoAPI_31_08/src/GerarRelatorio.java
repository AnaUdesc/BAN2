import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GerarRelatorio {

    public static void gerarRelatorioReservas(Connection conn, String diretorioSaida) {
    //Connection con = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    PrintWriter writer = null;

    Scanner scanner = new Scanner(System.in);
    System.out.print("Digite a matrícula do funcionário: ");
    int matricula = scanner.nextInt();

    try {
        // Configurar a conexão com o banco de dados PostgreSQL
        String url = "jdbc:postgresql://localhost:5432/creche";
        String user = "postgres";
        String password = "BAN2";
        conn = DriverManager.getConnection(url, user, password);

        // Consulta SQL para obter todas as reservas feitas pelo funcionário
        String sql = "SELECT r.id_reserva, a.nome_animal, p.nome_plano "
                   + "FROM reservas r "
                   + "INNER JOIN animais a ON r.id_animal = a.id_animal "
                   + "INNER JOIN planos p ON r.id_plano = p.id_plano "
                   + "WHERE r.matricula = ?";

        stmt = conn.prepareStatement(sql);
        stmt.setInt(1, matricula);

        // Execute a consulta SQL
        rs = stmt.executeQuery();
        
            // Especificar o diretório e o nome do arquivo de saída
            diretorioSaida = "C:\\Users\\anacl\\OneDrive\\Documentos\\BAN2";
            String arquivoSaida = "relatorio_reservas.txt";
            writer = new PrintWriter(new FileWriter(diretorioSaida + "/" + arquivoSaida));

            // Cabeçalho do relatório
            writer.println("+--------------------------------------+");
            writer.println("|  Relatório Reservas por Funcionário  |");
            writer.println("+--------------------------------------+");

            
            //arquivo.write("ID Reserva | CPF Cliente | Nome Cliente | Sobrenome Cliente | ID Animal | ID Plano | Data | Hora de Entrada | Hora de Saída | Observações | Status\n");
            
            writer.println("ID \tNome do Animal\tNome do Plano");
            writer.println("-----------------------------------");
            
            // Gravar o resultado no arquivo de saída
            while (rs.next()) {
                int idReserva = rs.getInt("id_reserva");
                String nomeAnimal = rs.getString("nome_animal");
                String nomePlano = rs.getString("nome_plano");

                // Títulos das informações em cima


                // Valores embaixo
                writer.println(idReserva + "\t" + nomeAnimal + "\t" + nomePlano);
                writer.println("-----------------------------------");
                
                /*String linhaRelatorio = String.format("%d | %s | %s%n",
                                                        idReserva, nomeAnimal, nomePlano);*/
                
            }


        System.out.println("Relatório gerado com sucesso em " + diretorioSaida + "/" + arquivoSaida);
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    
    /****************************/
    
    public static void gerarRelatorioReservasAnimal(Connection conn, String diretorioSaida) {
    //Connection con = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    PrintWriter writer = null;

    Scanner scanner = new Scanner(System.in);
    System.out.print("Digite o ID do animal: ");
    int id_animal = scanner.nextInt();

    try {
        // Configurar a conexão com o banco de dados PostgreSQL
        String url = "jdbc:postgresql://localhost:5432/creche";
        String user = "postgres";
        String password = "BAN2";
        conn = DriverManager.getConnection(url, user, password);

        // Consulta SQL para obter todas as reservas feitas pelo animal
        String sql = "SELECT r.id_reserva, a.nome_animal "
                   + "FROM reservas r "
                   + "INNER JOIN animais a ON r.id_animal = a.id_animal " + "WHERE r.id_animal = ?";

        stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id_animal);

        // Execute a consulta SQL
        rs = stmt.executeQuery();
        
        // Especificar o diretório e o nome do arquivo de saída
        diretorioSaida = "C:\\Users\\anacl\\OneDrive\\Documentos\\BAN2";
        String arquivoSaida = "relatorio_reservas_animal.txt";
        writer = new PrintWriter(new FileWriter(diretorioSaida + "/" + arquivoSaida));

        // Cabeçalho do relatório
        writer.println("+------------------------------------------+");
        writer.println("|  Relatório Reservas por Animal Selecionado  |");
        writer.println("+------------------------------------------+");

        writer.println("ID \tNome do Animal");
        writer.println("-----------------------------------");
        
        // Gravar o resultado no arquivo de saída
        while (rs.next()) {
            int idReserva = rs.getInt("id_reserva");
            String nomeAnimal = rs.getString("nome_animal");

            writer.println(idReserva + "\t" + nomeAnimal + "\t");
            writer.println("-----------------------------------");
        }

        System.out.println("Relatório gerado com sucesso em " + diretorioSaida + "/" + arquivoSaida);
    } catch (SQLException | IOException e) {
        e.printStackTrace();
    } finally {
        try {
            if (writer != null) {
                writer.close();
            }
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        }
    }

    /**************************/
    
    public static void gerarRelatorioAnimaisPorPlanos(Connection con, String diretorioSaida) {
    //con = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    PrintWriter writer = null;

    Scanner scanner = new Scanner(System.in);
    System.out.print("Digite o ID do plano: ");
    int idPlano = scanner.nextInt();

    try {
        // Configurar a conexão com o banco de dados PostgreSQL
        String url = "jdbc:postgresql://localhost:5432/creche";
        String user = "postgres";
        String password = "BAN2";
        con = DriverManager.getConnection(url, user, password);

        // Consulta SQL para obter todos os animais e seus respectivos tutores
        String sql = "SELECT a.nome_animal, c.cpf_cliente, r.id_plano, p.nome_plano " +
                     "FROM animais a " +
                     "INNER JOIN clientes c ON a.cpf_cliente = c.cpf_cliente " + 
                     "INNER JOIN reservas r ON a.id_animal = r.id_animal " +
                     "INNER JOIN planos p ON r.id_plano = p.id_plano " + 
                     "WHERE r.id_plano = ?";

        stmt = con.prepareStatement(sql);
        stmt.setInt(1, idPlano);

        // Execute a consulta SQL
        rs = stmt.executeQuery();

                // Obtenha a data e a hora atuais
        LocalDateTime dataHoraAtual = LocalDateTime.now();

        // Formate a data e a hora para incluir no nome do arquivo
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String dataHoraFormatada = dataHoraAtual.format(formatter);

        // Nome do arquivo com a data e a hora formatadas
        String arquivoSaida = "relatorio_animais_planos_" + dataHoraFormatada + ".txt";

        // Especificar o diretório e o nome do arquivo de saída
        diretorioSaida = "C:\\Users\\anacl\\OneDrive\\Documentos\\BAN2";
        writer = new PrintWriter(new FileWriter(diretorioSaida + "\\" + arquivoSaida));

        // Cabeçalho do relatório
        writer.println("+---------------------------------------------------------------------------------------------+");
        writer.println("|                                  Relatório Animais por Plano                                |");
        writer.println("+---------------------------------------------------------------------------------------------+");

            // Largura de cada coluna
        int larguraColuna = 25;

        // Cabeçalho das colunas
        writer.println(String.format("%-" + larguraColuna + "s | %-" + larguraColuna + "s | %-" + larguraColuna + "s | %-" + larguraColuna + "s", "Nome do Animal", "CPF do Tutor", "ID do Plano", "Nome do Plano"));
        writer.println(new String(new char[4 * larguraColuna]).replace('\0', '-'));

    // Gravar o resultado no arquivo de saída
    while (rs.next()) {
        String nomeAnimal = rs.getString("nome_animal");
        String cpfTutor = rs.getString("cpf_cliente");
        idPlano = rs.getInt("id_plano");
        String nomePlano = rs.getString("nome_plano");

            // Valores centralizados nas colunas
        String formattedNomeAnimal = String.format("%-" + larguraColuna + "s", nomeAnimal);
        String formattedCpfTutor = String.format("%-" + larguraColuna + "s", cpfTutor);
        String formattedIdPlano = String.format("%-" + larguraColuna + "s", String.valueOf(idPlano));
        String formattedNomePlano = String.format("%-" + larguraColuna + "s", nomePlano);

        writer.println(formattedNomeAnimal + " | " + formattedCpfTutor + " | " + formattedIdPlano + " | " + formattedNomePlano);
    }
        System.out.println("Relatório gerado com sucesso em " + diretorioSaida + "\\" + arquivoSaida);
    } catch (SQLException | IOException e) {
        e.printStackTrace();
    } finally {
        try {
            if (writer != null) {
                writer.close();
            }
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

}